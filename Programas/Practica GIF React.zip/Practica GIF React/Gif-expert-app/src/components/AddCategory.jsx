import { useState } from "react";

const AddCategory = () => {

    const [inputValue, setInputValue] = useState('One Punch');
    const onInputChange = (event) => {
        setInputValue(event.target.value);
    }

  return (
    <form>
        <input
            type="text"
            placeholder="Buscar gifs"
            value={inputValue}
            onChange={  onInputChange}
        />
    </form>
  )
}

export default AddCategory
AddCategory