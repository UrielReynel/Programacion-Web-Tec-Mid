import React, { useState } from 'react';
import AddCategory from './components/AddCategory';

const GifExpertApp = () => {

    const [categories, setCategories] = useState(['One Punch','Dragon Ball']);
    
    const onAddCategory = () => {
        //console.log('Valorant');
        //setCategories([...categories, 'Valorant']);
        setCategories( cats => [...cats, 'Valorant']);
    }

  return (
    <>
        <h1>GifExpertApp</h1>

        {/* Input */}
        <AddCategory />
        {/* Listado de gifs */}
        <button onClick={onAddCategory}>Agregar</button>
        <ol>
            {categories.map(category => {
                return <li key={category}>{category}</li>
            })
            }
        </ol>
            {/*gif items*/}
    </>
    )
}

export default GifExpertApp
